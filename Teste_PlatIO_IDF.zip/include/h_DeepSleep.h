#ifndef DeepSleep_h
#define DeepSleep_h

#include "driver/touch_sensor.h"
#include "esp_sleep.h"

void deepSleep_init(void);
void touchpad_test(void);

#endif